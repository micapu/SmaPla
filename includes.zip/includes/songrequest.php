

<?php
session_start();
if (!isset($_SESSION['u_uid'])) {
    exit();
} if (isset($_GET['getfiles'])) {
    require_once("connection.php");
    $result = mysqli_query($conn, "SELECT * FROM songs WHERE user_id = " . $_SESSION['u_id'] . ";");
    $songs = Array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($songs, $row['songname']);
    }
    $result = mysqli_query($conn, "SELECT * FROM activities WHERE user_id = " . $_SESSION['u_id'] . ";");
    if(mysqli_num_rows($result)==0){
        mysqli_query($conn,"INSERT INTO activities(user_id,JSON) VALUES (".$_SESSION['u_id'].", '{\"name\":\"Default Day\",\"type\":true}'  )");
        $result = mysqli_query($conn, "SELECT * FROM activities WHERE user_id = " . $_SESSION['u_id'] . ";");
    }
    $activies = Array();
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($activies, Array('id'=>$row['activityID'],'json'=>$row['JSON']));
    }
    echo(json_encode(Array("songs" =>$songs, "activities"=>$activies)));
    exit();
}
function error($msg){
    echo($msg);
    exit();
}

if(isset($_POST['event'])){
    require_once "connection.php";
    mysqli_query($conn,"INSERT INTO activities(user_id,JSON) VALUES (".$_SESSION['u_id'].",'".mysqli_real_escape_string($conn,$_POST['event'])."');");
    exit();
}


function data($code, $data){
    echo(json_encode(Array('data'=>$data,'code'=>$code)));
    exit();
}
if(isset($_POST['songName'])){
    require_once "connection.php";
    foreach($_POST as $k => $v){
        $_POST[$k] = mysqli_real_escape_string($conn,$v);
    }
    if(!($songhash = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM songs WHERE  user_id = ".$_SESSION['u_id']." AND songname = '".$_POST['songName']."';")))){
        data(1,"");
    }
    $songhash = $songhash['songhash'];
    $result = mysqli_query($conn,"SELECT * FROM songweights WHERE activityID = ".$_POST['activity']." AND user_id = ".$_SESSION['u_id']." AND songhash = '$songhash';");
    if(mysqli_num_rows($result)==0){
        mysqli_query($conn,"INSERT INTO songweights (user_id,songhash,activityID,JSON) VALUES (".$_SESSION['u_id'].",'$songhash','".$_POST['activity']."','".$_POST['data']."');");
        data(0,"");
    }
    $update = mysqli_query($conn, "UPDATE songweights SET JSON = '".$_POST['data']."' WHERE user_id = ".$_SESSION['u_id']." AND songhash = '$songhash' AND activityID = '".$_POST['activity']."';");
    data(0,"");

}

if(isset($_GET['songName'])){
    require_once "connection.php";
    foreach($_GET as $k => $v){
        $_GET[$k] = mysqli_real_escape_string($conn,$v);
    }
    if(!($songhash = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM songs WHERE songname = '".$_GET['songName']."';")))){
        data(1,"");
    }
    $songhash = $songhash['songhash'];
    if($result = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM songweights WHERE user_id = ".$_SESSION['u_id']." AND songhash = '$songhash' AND activityID = ".$_GET['activity'].";"))){
        data(0,$result['JSON']);
    }
    data(2,"");

}

if (isset($_SERVER["PATH_INFO"])) {
    require_once("connection.php");
    $_SERVER['PATH_INFO'] = mysqli_real_escape_string($conn, basename($_SERVER['PATH_INFO']));
    $song = mysqli_query($conn, "SELECT * FROM songs WHERE user_id = " . $_SESSION['u_id'] . " AND songname = '" . $_SERVER["PATH_INFO"] . "';");
    if (mysqli_num_rows($song) == 0) {
        http_response_code(404);
        die();
    }
    $file = mysqli_fetch_assoc($song)['location'];
    header('Content-Type: audio/' . pathinfo($file, PATHINFO_EXTENSION));
    header('Cache-Control: no-cache');
    header('HTTP/1.1 206 Partial Content');
    header('Content-Transfer-Encoding: binary');
    header('Content-Length: ' . filesize($file));
    header("Content-Range: 0-");
    header('Accept-Ranges: bytes');
    readfile($file);
}